using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class Spawner : MonoBehaviour
{
    //Pieces
    public GameObject[] pieces;
    public GameObject block;

    // Start is called before the first frame update
    void Start()
    {
        CreateAllBlocks();
        SpawnNext();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SpawnNext()
    {
        //Random Index
        int i = Random.Range(0, pieces.Length);

        // Spawn Group at current Position
        Instantiate(pieces[i], transform.position, Quaternion.identity);
    }
    
    public void CreateAllBlocks()
    {
        for (int y = 0; y < Board.h; y++)
        {
            for (int x = 0; x < Board.w; x++)
            {
                Debug.Log(x + " " + y);
                Board.grid[x, y] = Instantiate(block, new Vector3(x, y, 0), Quaternion.identity);
                Board.grid[x, y].gameObject.SetActive(false);
            }
        }
    }
}
