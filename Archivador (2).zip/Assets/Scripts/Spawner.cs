using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Object = System.Object;
using Random = UnityEngine.Random;

public class Spawner : MonoBehaviour
{
    //Pieces
    public GameObject[] pieces;
    public GameObject[] piecesCreated;
    public GameObject block;
    private GameObject lastPiece;

    // Start is called before the first frame update
    void Start()
    {
        CreatedPieces();
        CreateAllBlocks();
        SpawnNext();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SpawnNext()
    {
        if (lastPiece == null)
        {
            int i = Random.Range(0, pieces.Length);
            Instantiate(pieces[i], new Vector3(x, 30, 0), Quaternion.identity);
        }
        else
        {
            lastPiece.SetActive(false);
                spawnear llevar a la psicion
                activar
        }
    }
    
    public void CreateAllBlocks()
    {
        for (int y = 0; y < Board.h; y++)
        {
            for (int x = 0; x < Board.w; x++)
            {
                Debug.Log(x + " " + y);
                Board.grid[x, y] = Instantiate(block, new Vector3(x, y, 0), Quaternion.identity);
                Board.grid[x, y].gameObject.SetActive(false);
            }
        }
    }
    
    public void CreatedPieces()
    {
        for (int i = 0; i < piecesCreated.Length; i++)
        {
            piecesCreated[i] = Instantiate(pieces[i], new Vector3(0, 30, 0), Quaternion.identity);
            pieces[i].SetActive(false);
        }
    }
}
